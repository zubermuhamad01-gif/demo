/* ============================================================
   chokunafa — داتای مینیۆ
   ئەم فایلە تەنها شوێنە بۆ گۆڕینی ئایتم و نرخەکان.
   باشترین ڕێگە: admin.html بکەرەوە، گۆڕانکاری بکە، پاشان
   "داگرتنی data.js" دابگرە و لەجیاتی ئەم فایلە دایبنێ.
   ------------------------------------------------------------
   price  : نرخ بە دینار (تەنها ژمارە)
   img    : ناونیشانی وێنە، نموونە: "images/kunafa-nabulsi.jpg"
            ئەگەر بەتاڵ بێت یان وێنەکە نەبێت، وێنەیەکی جوانی خۆکار پیشان دەدرێت
   badge  : "" یان "new" (نوێ) یان "popular" (بەناوبانگ) یان "chef" (پێشنیاری ئێمە)
   available : false بکە ئەگەر ئایتمەکە ئێستا نییە
   ============================================================ */
window.MENU = {
  "brand": "chokunafa",
  "sloganKu": "کونافە و شیرینی · لە ٢٠٢٦ەوە",
  "sloganEn": "Kunafa & Pastry · Since 2026",
  "currencyKu": "دینار",
  "currencyEn": "IQD",
  "phone": "",
  "instagram": "",
  "addressKu": "",
  "addressEn": "",
  "categories": [
    {
      "id": "kunafa",
      "ku": "کونافە",
      "en": "Kunafa",
      "icon": "🧀",
      "items": [
        {
          "id": "k1",
          "ku": "کونافە بە پەنیر",
          "en": "Cheese Kunafa",
          "descKu": "کونافەی گەرم بە پەنیری تواوە و شەربەت",
          "descEn": "Warm kunafa with melted cheese and syrup",
          "ingKu": "کادەیف، پەنیر، کەرە، شەربەت، پستە",
          "ingEn": "Kataifi, cheese, butter, syrup, pistachio",
          "price": 2500,
          "img": "images/k1.jpg",
          "badge": "popular",
          "available": true
        },
        {
          "id": "k2",
          "ku": "کونافە بە فستق",
          "en": "Pistachio Kunafa",
          "descKu": "کونافە بە کرێمی فستق و فستقی هاڕاو",
          "descEn": "Kunafa with pistachio cream and crushed pistachio",
          "ingKu": "کادەیف، کرێمی فستق، فستقی هاڕاو، کەرە",
          "ingEn": "Kataifi, pistachio cream, crushed pistachio, butter",
          "price": 3500,
          "img": "images/k2.jpg",
          "badge": "chef",
          "available": true
        }
      ]
    },
    {
      "id": "pancake",
      "ku": "پانکێک",
      "en": "Pancake",
      "icon": "🥞",
      "items": [
        {
          "id": "p1",
          "ku": "مینی پانکێک (گەورە)",
          "en": "Mini Pancakes (Large)",
          "descKu": "مینی پانکێک بە سۆسی نۆتێلا و پیستاشیۆ و چکلێتی سپی، لەگەڵ مۆز و شلیک",
          "descEn": "Mini pancakes with Nutella, pistachio and white chocolate sauce, banana and strawberry",
          "ingKu": "مینی پانکێک، نۆتێلا، کرێمی پیستاشیۆ، چکلێتی سپی، مۆز، شلیک",
          "ingEn": "Mini pancakes, Nutella, pistachio cream, white chocolate, banana, strawberry",
          "price": 4000,
          "img": "images/p1.jpg",
          "badge": "popular",
          "available": true
        },
        {
          "id": "p2",
          "ku": "مینی پانکێک (بچووک)",
          "en": "Mini Pancakes (Small)",
          "descKu": "مینی پانکێک بە سۆسی نۆتێلا و پیستاشیۆ و چکلێتی سپی، لەگەڵ مۆز و شلیک",
          "descEn": "Mini pancakes with Nutella, pistachio and white chocolate sauce, banana and strawberry",
          "ingKu": "مینی پانکێک، نۆتێلا، کرێمی پیستاشیۆ، چکلێتی سپی، مۆز، شلیک",
          "ingEn": "Mini pancakes, Nutella, pistachio cream, white chocolate, banana, strawberry",
          "price": 2000,
          "img": "images/p1.jpg",
          "badge": "",
          "available": true
        }
      ]
    },
    {
      "id": "crepe",
      "ku": "کریپ",
      "en": "Crepe",
      "icon": "🌯",
      "items": [
        {
          "id": "c1",
          "ku": "کریپ نۆتێلا بە مۆز",
          "en": "Nutella Banana Crepe",
          "descKu": "کریپی تەنک بە نۆتێلا و مۆزی تازە",
          "descEn": "Thin crepe with Nutella and fresh banana",
          "ingKu": "کریپ، نۆتێلا، مۆز",
          "ingEn": "Crepe, Nutella, banana",
          "price": 1500,
          "img": "images/c1.jpg",
          "badge": "popular",
          "available": true
        },
        {
          "id": "c2",
          "ku": "کریپ کلاسیک",
          "en": "Classic Crepe",
          "descKu": "کریپی چکلێت بە مۆز و چکلێتی سپی",
          "descEn": "Chocolate crepe with banana and white chocolate drizzle",
          "ingKu": "کریپی چکلێت، مۆز، نۆتێلا، چکلێتی سپی",
          "ingEn": "Chocolate crepe, banana, Nutella, white chocolate",
          "price": 2500,
          "img": "images/c2.jpg",
          "badge": "",
          "available": true
        },
        {
          "id": "c3",
          "ku": "کریپی پیستاشیۆ کلاسیک",
          "en": "Classic Pistachio Crepe",
          "descKu": "کریپ بە نۆتێلا و کرێمی پیستاشیۆ",
          "descEn": "Crepe with Nutella and pistachio cream",
          "ingKu": "کریپ، نۆتێلا، کرێمی پیستاشیۆ",
          "ingEn": "Crepe, Nutella, pistachio cream",
          "price": 2500,
          "img": "images/c3.jpg",
          "badge": "new",
          "available": true
        },
        {
          "id": "c4",
          "ku": "کریپی لۆتوز",
          "en": "Lotus Crepe",
          "descKu": "کریپ بە نۆتێلا و سۆسی لۆتوز",
          "descEn": "Crepe with Nutella and Lotus spread",
          "ingKu": "کریپ، نۆتێلا، سۆسی لۆتوز",
          "ingEn": "Crepe, Nutella, Lotus spread",
          "price": 3500,
          "img": "images/c4.jpg",
          "badge": "",
          "available": true
        },
        {
          "id": "c5",
          "ku": "کریپی ئۆریۆ",
          "en": "Oreo Crepe",
          "descKu": "کریپ بە چکلێت و کرێمی ئۆریۆ",
          "descEn": "Crepe with chocolate and Oreo cream",
          "ingKu": "کریپ، چکلێت، کرێمی ئۆریۆ",
          "ingEn": "Crepe, chocolate, Oreo cream",
          "price": 3000,
          "img": "images/c5.jpg",
          "badge": "",
          "available": true
        }
      ]
    },
    {
      "id": "coffee",
      "ku": "قاوە",
      "en": "Coffee",
      "icon": "☕",
      "items": [
        {
          "id": "f1",
          "ku": "ئێسپریسۆ",
          "en": "Espresso",
          "descKu": "قاوەی بەهێز و چڕ",
          "descEn": "Strong, rich espresso shot",
          "ingKu": "قاوە",
          "ingEn": "Coffee",
          "price": 2000,
          "img": "images/f1.jpg",
          "badge": "",
          "available": true
        }
      ]
    },
    {
      "id": "mojito",
      "ku": "مۆهیتۆ",
      "en": "Mojito",
      "icon": "🍹",
      "items": [
        {
          "id": "m1",
          "ku": "مۆهیتۆی شلیک",
          "en": "Strawberry Mojito",
          "descKu": "شلیکی تازە، نەعنا و لیمۆ بە سۆدا",
          "descEn": "Fresh strawberry, mint and lime with soda",
          "ingKu": "شلیک، نەعنا، لیمۆ، سۆدا، سەهۆڵ",
          "ingEn": "Strawberry, mint, lime, soda, ice",
          "price": 2000,
          "img": "images/m1.jpg",
          "badge": "",
          "available": true
        },
        {
          "id": "m2",
          "ku": "مۆهیتۆی کۆراساو",
          "en": "Blue Curaçao Mojito",
          "descKu": "مۆهیتۆی شین بە شەربەتی کۆراساو",
          "descEn": "Blue mojito with curaçao syrup",
          "ingKu": "شەربەتی کۆراساو، نەعنا، لیمۆ، سۆدا، سەهۆڵ",
          "ingEn": "Curaçao syrup, mint, lime, soda, ice",
          "price": 2000,
          "img": "images/m2.jpg",
          "badge": "",
          "available": true
        },
        {
          "id": "m3",
          "ku": "مۆهیتۆی سێو",
          "en": "Apple Mojito",
          "descKu": "سێو، نەعنا و لیمۆ بە سۆدا",
          "descEn": "Apple, mint and lime with soda",
          "ingKu": "سێو، نەعنا، لیمۆ، سۆدا، سەهۆڵ",
          "ingEn": "Apple, mint, lime, soda, ice",
          "price": 2000,
          "img": "images/m3.jpg",
          "badge": "",
          "available": true
        },
        {
          "id": "m4",
          "ku": "مۆهیتۆی لیمۆ",
          "en": "Lemon Mojito",
          "descKu": "مۆهیتۆی کلاسیک بە لیمۆ و نەعنای تازە",
          "descEn": "Classic mojito with lemon and fresh mint",
          "ingKu": "لیمۆ، نەعنا، سۆدا، سەهۆڵ",
          "ingEn": "Lemon, mint, soda, ice",
          "price": 2000,
          "img": "images/m4.jpg",
          "badge": "",
          "available": true
        }
      ]
    }
  ]
};
