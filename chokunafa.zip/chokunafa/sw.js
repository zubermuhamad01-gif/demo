/* chokunafa — offline cache. ئەگەر گۆڕانکاریت کرد، ژمارەی VERSION زیاد بکە */
const VERSION = "ck-v14";
const CORE = ["./","index.html","data.js","manifest.json","images/logo.webp"];
self.addEventListener("install", e => { e.waitUntil(caches.open(VERSION).then(c => c.addAll(CORE)).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  const r = e.request; if (r.method !== "GET") return;
  const u = new URL(r.url);
  // data.js & html: network first (new prices show immediately), cache as fallback
  if (u.origin === location.origin && (u.pathname.endsWith("data.js") || r.mode === "navigate")) {
    e.respondWith(fetch(r).then(res => { const cp = res.clone(); caches.open(VERSION).then(c => c.put(r, cp)); return res; }).catch(() => caches.match(r).then(m => m || caches.match("index.html"))));
    return;
  }
  // images, fonts: cache first
  e.respondWith(caches.match(r).then(m => m || fetch(r).then(res => { if (res.ok || res.type === "opaque") { const cp = res.clone(); caches.open(VERSION).then(c => c.put(r, cp)); } return res; })));
});
