/* Tiny QR Code encoder (byte mode, versions 1–40, ECC L/M/Q/H).
   Algorithm after Project Nayuki's QR Code generator (MIT). No dependencies, works offline. */
(function (g) {
  "use strict";
  const ECC = { L: [1, 0], M: [0, 1], Q: [3, 2], H: [2, 3] }; // [formatBits, tableIndex]
  const ECW = [
    [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
    [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28],
    [-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
    [-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30]];
  const NB = [
    [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25],
    [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49],
    [-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68],
    [-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 10, 19, 18, 16, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81]];
  const bit = (x, i) => ((x >>> i) & 1) !== 0;
  function rawModules(v) { let r = (16 * v + 128) * v + 64; if (v >= 2) { const n = Math.floor(v / 7) + 2; r -= (25 * n - 10) * n - 55; if (v >= 7) r -= 36; } return r; }
  function dataCw(v, e) { return Math.floor(rawModules(v) / 8) - ECW[e][v] * NB[e][v]; }
  function mul(x, y) { let z = 0; for (let i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11D); z ^= ((y >>> i) & 1) * x; } return z & 0xFF; }
  function rsDiv(d) { const r = new Array(d).fill(0); r[d - 1] = 1; let root = 1; for (let i = 0; i < d; i++) { for (let j = 0; j < r.length; j++) { r[j] = mul(r[j], root); if (j + 1 < r.length) r[j] ^= r[j + 1]; } root = mul(root, 2); } return r; }
  function rsRem(data, div) { const r = div.map(() => 0); for (const b of data) { const f = b ^ r.shift(); r.push(0); div.forEach((c, i) => r[i] ^= mul(c, f)); } return r; }
  function utf8(s) { return Array.from(new TextEncoder().encode(s)); }

  function encode(text, eclName) {
    const bytes = utf8(text);
    let [fmt, e] = ECC[eclName || "M"];
    let ver = 0, bits;
    for (let v = 1; v <= 40; v++) {
      const ccBits = v <= 9 ? 8 : 16;
      const need = 4 + ccBits + bytes.length * 8;
      if (need <= dataCw(v, e) * 8) { ver = v; break; }
    }
    if (!ver) throw new Error("Text too long for QR");
    // build bit stream
    bits = [];
    const push = (val, len) => { for (let i = len - 1; i >= 0; i--) bits.push((val >>> i) & 1); };
    push(4, 4); push(bytes.length, ver <= 9 ? 8 : 16); bytes.forEach(b => push(b, 8));
    const cap = dataCw(ver, e) * 8;
    push(0, Math.min(4, cap - bits.length));
    push(0, (8 - bits.length % 8) % 8);
    for (let p = 0xEC; bits.length < cap; p ^= 0xEC ^ 0x11) push(p, 8);
    const data = []; for (let i = 0; i < bits.length; i += 8) { let b = 0; for (let j = 0; j < 8; j++) b = (b << 1) | bits[i + j]; data.push(b); }

    // ECC + interleave
    const nb = NB[e][ver], el = ECW[e][ver], raw = Math.floor(rawModules(ver) / 8);
    const nShort = nb - raw % nb, shortLen = Math.floor(raw / nb), div = rsDiv(el);
    const blocks = []; for (let i = 0, k = 0; i < nb; i++) {
      const d = data.slice(k, k + shortLen - el + (i < nShort ? 0 : 1)); k += d.length;
      const ec = rsRem(d, div); if (i < nShort) d.push(0); blocks.push(d.concat(ec));
    }
    const all = []; for (let i = 0; i < blocks[0].length; i++) blocks.forEach((b, j) => { if (i !== shortLen - el || j >= nShort) all.push(b[i]); });

    // matrix
    const size = ver * 4 + 17;
    const M = [...Array(size)].map(() => Array(size).fill(false));
    const F = [...Array(size)].map(() => Array(size).fill(false));
    const set = (x, y, d) => { M[y][x] = d; F[y][x] = true; };
    for (let i = 0; i < size; i++) { set(6, i, i % 2 === 0); set(i, 6, i % 2 === 0); }
    const finder = (x, y) => { for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) { const d = Math.max(Math.abs(dx), Math.abs(dy)), xx = x + dx, yy = y + dy; if (xx >= 0 && xx < size && yy >= 0 && yy < size) set(xx, yy, d !== 2 && d !== 4); } };
    finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
    const align = []; if (ver > 1) { const n = Math.floor(ver / 7) + 2; const step = Math.floor((ver * 8 + n * 3 + 5) / (n * 4 - 4)) * 2; align.push(6); for (let p = size - 7; align.length < n; p -= step) align.splice(1, 0, p); }
    const na = align.length;
    for (let i = 0; i < na; i++) for (let j = 0; j < na; j++) {
      if ((i === 0 && j === 0) || (i === 0 && j === na - 1) || (i === na - 1 && j === 0)) continue;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) set(align[i] + dx, align[j] + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
    }
    const drawFormat = mask => {
      const d = fmt << 3 | mask; let r = d; for (let i = 0; i < 10; i++) r = (r << 1) ^ ((r >>> 9) * 0x537);
      const b = (d << 10 | r) ^ 0x5412;
      for (let i = 0; i <= 5; i++) set(8, i, bit(b, i));
      set(8, 7, bit(b, 6)); set(8, 8, bit(b, 7)); set(7, 8, bit(b, 8));
      for (let i = 9; i < 15; i++) set(14 - i, 8, bit(b, i));
      for (let i = 0; i < 8; i++) set(size - 1 - i, 8, bit(b, i));
      for (let i = 8; i < 15; i++) set(8, size - 15 + i, bit(b, i));
      set(8, size - 8, true);
    };
    drawFormat(0);
    if (ver >= 7) { let r = ver; for (let i = 0; i < 12; i++) r = (r << 1) ^ ((r >>> 11) * 0x1F25); const b = ver << 12 | r; for (let i = 0; i < 18; i++) { const c = bit(b, i), a = size - 11 + i % 3, q = Math.floor(i / 3); set(a, q, c); set(q, a, c); } }
    // codewords
    let i = 0;
    for (let right = size - 1; right >= 1; right -= 2) {
      if (right === 6) right = 5;
      for (let v = 0; v < size; v++) for (let j = 0; j < 2; j++) {
        const x = right - j, up = ((right + 1) & 2) === 0, y = up ? size - 1 - v : v;
        if (!F[y][x] && i < all.length * 8) { M[y][x] = bit(all[i >>> 3], 7 - (i & 7)); i++; }
      }
    }
    const maskFn = [(x, y) => (x + y) % 2 === 0, (x, y) => y % 2 === 0, x => x % 3 === 0, (x, y) => (x + y) % 3 === 0,
      (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0, (x, y) => x * y % 2 + x * y % 3 === 0,
      (x, y) => (x * y % 2 + x * y % 3) % 2 === 0, (x, y) => ((x + y) % 2 + x * y % 3) % 2 === 0];
    const applyMask = m => { for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) if (!F[y][x] && maskFn[m](x, y)) M[y][x] = !M[y][x]; };
    const penalty = () => {
      let p = 0, dark = 0;
      const line = get => { for (let a = 0; a < size; a++) { let run = 1; for (let b = 1; b <= size; b++) { if (b < size && get(a, b) === get(a, b - 1)) run++; else { if (run >= 5) p += run - 2; run = 1; } } } };
      line((a, b) => M[a][b]); line((a, b) => M[b][a]);
      for (let y = 0; y < size - 1; y++) for (let x = 0; x < size - 1; x++) { const c = M[y][x]; if (c === M[y][x + 1] && c === M[y + 1][x] && c === M[y + 1][x + 1]) p += 3; }
      const pat1 = [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0], pat2 = [0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1];
      const chk = get => { for (let a = 0; a < size; a++) for (let b = 0; b + 11 <= size; b++) { let m1 = true, m2 = true; for (let k = 0; k < 11; k++) { const v = get(a, b + k) ? 1 : 0; if (v !== pat1[k]) m1 = false; if (v !== pat2[k]) m2 = false; } if (m1) p += 40; if (m2) p += 40; } };
      chk((a, b) => M[a][b]); chk((a, b) => M[b][a]);
      M.forEach(r => r.forEach(c => { if (c) dark++; }));
      const tot = size * size; p += (Math.ceil(Math.abs(dark * 20 - tot * 10) / tot) - 1) * 10;
      return p;
    };
    let best = 0, bestP = Infinity;
    for (let m = 0; m < 8; m++) { applyMask(m); drawFormat(m); const p = penalty(); if (p < bestP) { bestP = p; best = m; } applyMask(m); }
    applyMask(best); drawFormat(best);
    return { size, version: ver, modules: M };
  }

  /* Styled SVG: rounded dots + rounded finder eyes + optional center logo */
  function toSVG(text, o) {
    o = Object.assign({ ecl: "H", color: "#0A1A3F", bg: "#ffffff", margin: 2, logo: "", logoBg: "#0A1A3F", logoColor: "#fff", style: "dots" }, o || {});
    const q = encode(text, o.ecl), n = q.size, m = o.margin, S = n + m * 2;
    const inEye = (x, y) => (x < 7 && y < 7) || (x >= n - 7 && y < 7) || (x < 7 && y >= n - 7);
    const L = (o.logo || o.logoImg) ? Math.round(n * (o.logoImg ? 0.27 : 0.22)) | 1 : 0, l0 = (n - L) / 2;
    const inLogo = (x, y) => L && x >= l0 - 0.5 && x < l0 + L + 0.5 && y >= l0 - 0.5 && y < l0 + L + 0.5;
    let p = "";
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      if (!q.modules[y][x] || inEye(x, y) || inLogo(x, y)) continue;
      if (o.style === "square") p += `M${x + m},${y + m}h1v1h-1z`;
      else p += `M${x + m + .5},${y + m + .08}a.42,.42 0 1,1 0,.84a.42,.42 0 1,1 0,-.84z`;
    }
    const eye = (x, y) => `<rect x="${x + m + .5}" y="${y + m + .5}" width="6" height="6" rx="1.9" fill="none" stroke="${o.color}" stroke-width="1"/><rect x="${x + m + 2}" y="${y + m + 2}" width="3" height="3" rx="1" fill="${o.color}"/>`;
    let logo = "";
    if (L && o.logoImg) { const cx = l0 + m + L / 2, R = L / 2 + .6; logo = `<circle cx="${cx}" cy="${cx}" r="${R}" fill="#FAF9F5"/><image href="${o.logoImg}" x="${cx - L / 2}" y="${cx - L / 2}" width="${L}" height="${L}"/>`; }
    else if (L) logo = `<rect x="${l0 + m}" y="${l0 + m}" width="${L}" height="${L}" rx="${L * .26}" fill="${o.logoBg}"/><text x="${l0 + m + L / 2}" y="${l0 + m + L * .74}" font-size="${L * .78}" text-anchor="middle" fill="${o.logoColor}" font-family="'Lazy Dog','Chewy',Arial Black,sans-serif">${o.logo}</text>`;
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${S} ${S}" shape-rendering="geometricPrecision"><rect width="${S}" height="${S}" fill="${o.bg}"/><path d="${p}" fill="${o.color}"/>${eye(0, 0)}${eye(n - 7, 0)}${eye(0, n - 7)}${logo}</svg>`;
  }
  g.QR = { encode, toSVG };
})(typeof window !== "undefined" ? window : globalThis);
